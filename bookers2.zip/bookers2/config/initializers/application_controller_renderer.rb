# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '2af40d0911c83ca53a070b39e94d43740abafb0daf81ab829bc2f28e4f73a243b2918aeec8bf6335b5040f771fac6eafb62ce99210781b9a2bb8606039fccb84'